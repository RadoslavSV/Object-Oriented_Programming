/// Radoslav Velkov, 1 group, FN 62528

#pragma once
#include "Request.hpp"

class LeavingRequest: public Request{
private:
public:
    LeavingRequest(const std::string& sender="");

};


